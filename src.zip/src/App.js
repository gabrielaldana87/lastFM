import React from 'react';
import PlayList from './components/Tracks';
const App = () => {
  return (
    <PlayList/>
  )
};

export default App;